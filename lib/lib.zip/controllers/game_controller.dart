import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';

/// Represents the result of an attempted move
enum MoveResult { valid, cellOccupied, gameOver }

/// Core Game Controller managing 2-Player Tic-Tac-Toe state, turn rotation,
/// win/draw calculations, scores, and tactile feedback events.
class GameController extends ChangeNotifier {
  // 1D list representing the 3x3 board grid (0 to 8)
  List<String> _board = List.generate(9, (_) => '');

  // Current active player: 'X' (Player 1) or 'O' (Player 2)
  String _currentPlayer = 'X';

  // Winner if match has concluded ('X' or 'O'), or null if match is ongoing
  String? _winner;

  // Winning line indices (e.g. [0, 1, 2]), or null if no winner
  List<int>? _winningLine;

  // Draw flag
  bool _isDraw = false;

  // Turn count for the current match
  int _turnsCount = 0;

  // Aggregate scores across matches
  int _scoreX = 0;
  int _scoreO = 0;

  // Audio mute status (visual toggle)
  bool _isSoundMuted = false;

  // Tracks the most recent cell where an invalid tap occurred for UI shake feedback
  int? _invalidCellIndex;

  // The 8 possible winning combinations for 3x3 Tic-Tac-Toe
  static const List<List<int>> winningCombinations = [
    [0, 1, 2], // Row 0
    [3, 4, 5], // Row 1
    [6, 7, 8], // Row 2
    [0, 3, 6], // Col 0
    [1, 4, 7], // Col 1
    [2, 5, 8], // Col 2
    [0, 4, 8], // Diagonal top-left to bottom-right
    [2, 4, 6], // Diagonal top-right to bottom-left
  ];

  // Getters
  List<String> get board => List.unmodifiable(_board);
  String get currentPlayer => _currentPlayer;
  String? get winner => _winner;
  List<int>? get winningLine => _winningLine;
  bool get isDraw => _isDraw;
  bool get isGameOver => _winner != null || _isDraw;
  int get turnsCount => _turnsCount;
  int get scoreX => _scoreX;
  int get scoreO => _scoreO;
  bool get isSoundMuted => _isSoundMuted;
  int? get invalidCellIndex => _invalidCellIndex;

  /// Attempts to make a move at the specified [index].
  /// Returns [MoveResult] indicating success or reason for failure.
  MoveResult makeMove(int index) {
    if (index < 0 || index >= 9) return MoveResult.gameOver;

    // Reject if game is already over
    if (isGameOver) {
      _triggerInvalidMove(index);
      return MoveResult.gameOver;
    }

    // Reject if cell is already occupied
    if (_board[index].isNotEmpty) {
      _triggerInvalidMove(index);
      return MoveResult.cellOccupied;
    }

    // Valid move: update board
    _invalidCellIndex = null;
    _board[index] = _currentPlayer;
    _turnsCount++;

    // Tactile haptic feedback on successful move
    if (!_isSoundMuted) {
      HapticFeedback.lightImpact();
    }

    // Check win condition
    final winCombo = _checkWinCondition(_board, _currentPlayer);
    if (winCombo != null) {
      _winner = _currentPlayer;
      _winningLine = winCombo;
      if (_currentPlayer == 'X') {
        _scoreX++;
      } else {
        _scoreO++;
      }
      if (!_isSoundMuted) {
        HapticFeedback.heavyImpact();
      }
      notifyListeners();
      return MoveResult.valid;
    }

    // Check draw condition
    if (!_board.contains('')) {
      _isDraw = true;
      if (!_isSoundMuted) {
        HapticFeedback.mediumImpact();
      }
      notifyListeners();
      return MoveResult.valid;
    }

    // Next player's turn
    _currentPlayer = (_currentPlayer == 'X') ? 'O' : 'X';
    notifyListeners();
    return MoveResult.valid;
  }

  /// Triggers an invalid move feedback event for the cell at [index]
  void _triggerInvalidMove(int index) {
    _invalidCellIndex = index;
    if (!_isSoundMuted) {
      HapticFeedback.vibrate();
    }
    notifyListeners();

    // Clear the invalid cell index shortly after so it can be re-triggered
    Future.delayed(const Duration(milliseconds: 400), () {
      if (_invalidCellIndex == index) {
        _invalidCellIndex = null;
        notifyListeners();
      }
    });
  }

  /// Evaluates whether the given [player] has satisfied any winning combination
  List<int>? _checkWinCondition(List<String> b, String player) {
    for (final combo in winningCombinations) {
      if (b[combo[0]] == player &&
          b[combo[1]] == player &&
          b[combo[2]] == player) {
        return combo;
      }
    }
    return null;
  }

  /// Clears the board and starts a new match while preserving player scores
  void resetMatch() {
    _board = List.generate(9, (_) => '');
    _currentPlayer = 'X';
    _winner = null;
    _winningLine = null;
    _isDraw = false;
    _turnsCount = 0;
    _invalidCellIndex = null;
    notifyListeners();
  }

  /// Complete reset clearing match state and all scores
  void resetAll() {
    resetMatch();
    _scoreX = 0;
    _scoreO = 0;
    notifyListeners();
  }

  /// Toggles sound mute state
  void toggleSound() {
    _isSoundMuted = !_isSoundMuted;
    notifyListeners();
  }
}
